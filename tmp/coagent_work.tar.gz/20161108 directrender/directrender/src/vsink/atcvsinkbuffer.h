
#ifndef __ATC_VSINK_BUFFER_H__
#define __ATC_VSINK_BUFFER_H__

#include <linux/types.h>
#include <glib.h>
#include "atcsurface.h"
#include "atcvideosink.h"


typedef struct _AtcSinkBuffer {
  __s32     index;
  __s32     width;
  __s32     height;
  __u32     stride;
  __u32     format;
  __u32     fourcc;
  __s32     state;
  bool      need_destroy;
  void *    bufctrl;
  void *    data;
  __u32     size;
  void *    lock;
  void *    pool;
} ATCVSINKBUFFER;

#define ATC_SINK_BUFFER_LOCK(atcsinkbuf)   if (((ATCVSINKBUFFER *)atcsinkbuf)->lock) g_mutex_lock (((ATCVSINKBUFFER *)atcsinkbuf)->lock)
#define ATC_SINK_BUFFER_UNLOCK(atcsinkbuf)   if (((ATCVSINKBUFFER *)atcsinkbuf)->lock) g_mutex_unlock (((ATCVSINKBUFFER *)atcsinkbuf)->lock)

#ifdef __cplusplus
extern "C" {
#endif

ATCVSINKBUFFER *atc_vsink_buffer_new (void * owner,void *atcsurface,
  __s32 index, ATC_VSINK_FMT_INFO_T *format_info);

void atc_vsink_buffer_free (void *buf);

#ifdef __cplusplus
}
#endif

#endif /* __ATC_VSINK_BUFFER_H__ */

