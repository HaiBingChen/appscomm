
#include <stdbool.h>
#include <sys/mman.h>
#include <string.h>
#include <unistd.h>
#include <linux/types.h>
#include <glib.h>
#include "atcsurface.h"
#include "atcvbufferpool.h"
#include "atcvsinkbuffer.h"
#include "atcvdecdsplog.h"
#include "display.h"

#define  DEBUG_ATCSURFACE_RETCODE 0

#define ENABLE_SYSLOG_DEBUG 0

#if ENABLE_SYSLOG_DEBUG
#define PRINT_DEBUG VDECDSP_PRINT_TRACE
#else
#define PRINT_DEBUG VDECDSP_PRINT_DBG
#endif

#define PRINT_TRACE     VDECDSP_PRINT_TRACE
#define PRINT_ERROR     VDECDSP_PRINT_ERROR

enum  {
  atcbuf_idle,
  atcbuf_indec,
  atcbuf_inme
};

void atc_vsink_buffer_free (void *buf)
{
  ATCVSINKBUFFER *atcvsinkbuf = (ATCVSINKBUFFER *)buf;
  __s32 index = 0;

  g_return_if_fail (atcvsinkbuf != NULL);

  if (atcvsinkbuf->bufctrl != NULL) {
    g_free(atcvsinkbuf->bufctrl);
  }

  index = atcvsinkbuf->index;

  atcvsinkbuf->bufctrl = NULL;
  atcvsinkbuf->data = NULL;
  atcvsinkbuf->size = 0;
  
  if (atcvsinkbuf->lock) {
    g_mutex_free(atcvsinkbuf->lock);
    atcvsinkbuf->lock = NULL;
  }

  PRINT_DEBUG("[atcvsinkbuf] %s (idx: %d) enter\r\n",
    __FUNCTION__, index);
}

ATCVSINKBUFFER *
atc_vsink_buffer_new (void * owner,
  void *atcsurface, __s32 index,
  ATC_VSINK_FMT_INFO_T *format_info)
{
  ATCVSINKBUFFER *atcsinkbuf = NULL;
  atc_buffer_t *atcbuf = NULL;
  struct VOUT_PARAM *vid_out_data = NULL;
  __s32 ret = 0;

  PRINT_DEBUG("[atcsinkbuf] new(idx: %d), pool(%p) enter\r\n",
    index, owner);

  if (NULL == owner) {
    PRINT_ERROR("[atcsinkbuf] %s line %d fail for invalid args\r\n",
      __FUNCTION__, __LINE__);
    return NULL;
  }

  atcsinkbuf = g_malloc0(sizeof(ATCVSINKBUFFER));
  if (NULL == atcsinkbuf) {
    PRINT_ERROR("[atcsinkbuf] %s line %d fail for no memory\r\n",
      __FUNCTION__, __LINE__);
    return NULL;
  }
  
  atcsinkbuf->lock = g_mutex_new ();
  atcsinkbuf->index = -1;
  atcsinkbuf->format = 0;
  atcsinkbuf->fourcc = 0;
  atcsinkbuf->width  = 0;
  atcsinkbuf->height = 0;
  atcsinkbuf->stride = 0;
  atcsinkbuf->state = atcbuf_idle;
  atcsinkbuf->need_destroy = FALSE;
  atcsinkbuf->bufctrl = NULL;
  atcsinkbuf->data = NULL;
  atcsinkbuf->size = 0;
  atcsinkbuf->pool = NULL;

  ATC_SINK_BUFFER_LOCK(atcsinkbuf);

  atcsinkbuf->pool = owner;

  atcsinkbuf->index = index;
  atcsinkbuf->format = format_info->format;
  atcsinkbuf->fourcc = format_info->fourcc;
  atcsinkbuf->width  = format_info->width;
  atcsinkbuf->height = format_info->height;
  atcsinkbuf->stride = format_info->stride;

  atcsinkbuf->state = atcbuf_idle;
  
  PRINT_DEBUG("[atcsinkbuf] new --> format: 0x%08x\r\n",
    format_info->format);
  if (ATC_PIX_FMT_NV12M_PRIVATE1 == format_info->format) {
    PRINT_DEBUG("[atcsinkbuf] new --> g_malloc atc_buffer_t\r\n");
    if (atcsinkbuf->bufctrl != NULL) {
      g_free(atcsinkbuf->bufctrl);
      atcsinkbuf->bufctrl = NULL;
    }
    atcsinkbuf->bufctrl = g_malloc0(sizeof(atc_buffer_t));
    if (NULL == atcsinkbuf->bufctrl) {
      PRINT_ERROR("[atcsinkbuf] new fail in g_malloc atc_buffer_t\r\n");
      ATC_SINK_BUFFER_UNLOCK(atcsinkbuf);
      atc_vsink_buffer_free(atcsinkbuf);
      return NULL;
    }
    memset(atcsinkbuf->bufctrl, 0, sizeof(atc_buffer_t));
  }
  
  PRINT_DEBUG("[atcsinkbuf] new --> IAtcSurface_dequeueBuffer\r\n");
  ret = IAtcSurface_dequeueBuffer((IAtcSurface *)atcsurface, atcsinkbuf->bufctrl);
  if (ret != 0) {
    PRINT_TRACE("[atcsinkbuf] new (idx: %d) fail in IAtcSurface_dequeueBuffer\r\n",
      index);
    goto dequeuebuffail;
  }

  atcbuf = (atc_buffer_t *)(atcsinkbuf->bufctrl);

  if (NULL == atcbuf->bits) {
    PRINT_TRACE("[atcsinkbuf] new (idx: %d) fail for atcbuf->bits == NULL\r\n",
      index);
    goto dequeuebuffail;
  }

  atcsinkbuf->data = atcbuf->bits;

  atcsinkbuf->state = atcbuf_inme;

  if (ATC_PIX_FMT_NV12M_PRIVATE1 == format_info->format) {
    atcbuf->format = ATC_PIX_FMT_NV12M_PRIVATE1;
    vid_out_data = (struct VOUT_PARAM *)(atcbuf->bits);
    if (vid_out_data != NULL) {
      PRINT_TRACE("[atcsinkbuf] new(%p) --> dequeue pool buffer (index=%d), bufctrl=%p, bits=%p, y=0x%x, c=0x%x",
        atcsinkbuf, index, atcsinkbuf->bufctrl, vid_out_data,
        (unsigned int)(vid_out_data->y_phy_addr), 
        (unsigned int)(vid_out_data->c_phy_addr));
      atcsinkbuf->size = sizeof(struct VOUT_PARAM);
    } else {
      PRINT_TRACE("[atcsinkbuf] new(%p) FATAL ERROR --> dequeue pool buffer (index=%d), bufctrl=%p, bits=(nil)",
        atcsinkbuf, index, atcsinkbuf->bufctrl);
      atcsinkbuf->size = 0;
			IAtcSurface_queueBuffer((IAtcSurface *)atcsurface, atcsinkbuf->bufctrl);
			goto dequeuebuffail;
    }
  }
  
  ATC_SINK_BUFFER_UNLOCK(atcsinkbuf);
  PRINT_DEBUG("[atcsinkbuf] new(idx: %d) success, pool(%p), return %p\r\n",
    index, owner, atcsinkbuf);

  return atcsinkbuf;

  /* ERRORS */
dequeuebuffail:
  {
    ATC_SINK_BUFFER_UNLOCK(atcsinkbuf);
    atc_vsink_buffer_free(atcsinkbuf);
    return NULL;
  }
}


