/* GStreamer
 *
 * Copyright (C) 2001-2002 Ronald Bultje <rbultje@ronald.bitfreak.net>
 *               2006 Edgard Lima <edgard.lima@indt.org.br>
 *               2009 Texas Instruments, Inc - http://www.ti.com/
 *
 * gstv4l2bufferpool.h V4L2 buffer pool class
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA 02111-1307, USA.
 */

#ifndef __ATC_VSINKBUFFERPOOL_H__
#define __ATC_VSINKBUFFERPOOL_H__

#include "atcsurface.h"
#include <atcsema.h>
#include "atcvsinkbuffer.h"

#ifdef __cplusplus
extern "C" {
#endif

void atc_vsink_buffer_pool_destroy (void * pool);

bool atc_vsink_buffer_pool_init_buffers (void *pool,
    __s32 num_buffers,  ATC_VSINK_FMT_INFO_T *prFormat);

bool atc_vsink_buffer_pool_reset(void * pool,
    ATC_VSINK_FMT_INFO_T *prFormat);

void *atc_vsink_buffer_pool_new (void *parent);
bool atc_vsink_buffer_pool_free (void *atcpool);

bool atc_vsink_buffer_pool_get (void * pool, bool blocking,
    void **ppBuffer, __u32 *pBuflen);
bool atc_vsink_buffer_pool_qbuf (void * pool, void *pBuffer, __u32 buflen);
bool atc_vsink_buffer_pool_dqbuf (void * pool);

bool atc_vsink_buffer_pool_unshow (void * pool, void *pBuffer, __u32 buflen);

__s32 atc_vsink_buffer_pool_available_buffers (void *pool);

bool atc_vsink_buffer_pool_recycle_buffers (void * pool);

void *atc_vsink_buffer_pool_get_surface (void * pool);
void  atc_vsink_buffer_pool_set_surface (void *pool, void *surface);

#ifdef __cplusplus
}
#endif

#endif /* __GSTATCSINKBUFFER_H__ */
