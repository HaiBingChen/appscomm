#include <linux/types.h>
#include <stdbool.h>
#include <glib.h>
#include <string.h>             /* for memcpy */
#include <unistd.h>
#include <stdbool.h>
#include <linux/types.h>
#include <sys/time.h>
#include <gstatcmimetype.h>
#include "atcomxutils.h"
#include "atcomxvdecinst.h"
#include <async_queue.h>
#include "atcvdecdsplog.h"
#include "atcsurface.h"
#include "display.h"

#define ATC_OMXVDEC_INST_MOD "[atcomxvdecinst]"
#define ATC_OMXVDEC_INST_MAJ  1
#define ATC_OMXVDEC_INST_MIN  1
#define ATC_OMXVDEC_INST_REV  4

#define ATC_CLOCK_TIME_NONE   ((__s64)(-1))
/* 2ms */
#define ATC_OUTLOOP_SEPERATE_TIME (G_USEC_PER_SEC / 500)

#define VDEC_DEBUG_ON   0
#if VDEC_DEBUG_ON
#define PRINT_DEBUG VDECDSP_PRINT_TRACE
#else
#define PRINT_DEBUG VDECDSP_PRINT_DBG
#endif

#define VDEC_DEBUG_OUTLOOP_ON   0
#if VDEC_DEBUG_OUTLOOP_ON
#define PRINT_OUTLOOP_DEBUG VDECDSP_PRINT_TRACE
#else
#define PRINT_OUTLOOP_DEBUG VDECDSP_PRINT_DBG
#endif

#define VDEC_DEBUG_ETB_ON  0
//#if VDEC_DEBUG_ETB_ON
//#define PRINT_DEBUG_ETB VDECDSP_PRINT_TRACE
//#else
#define PRINT_DEBUG_ETB VDECDSP_PRINT_DBG
//#endif

#define DEBUG_GSTMG_MEM_ON 0
#if DEBUG_GSTMG_MEM_ON
#define DEBUG_GSTMG_MEM VDECDSP_PRINT_TRACE
#else
#define DEBUG_GSTMG_MEM VDECDSP_PRINT_DBG
#endif

#define VDEC_DEBUG_FLUSHBUF_ON 0
#if VDEC_DEBUG_FLUSHBUF_ON
#define PRINT_DEBUG_FLUSHBUF VDECDSP_PRINT_TRACE
#else
#define PRINT_DEBUG_FLUSHBUF VDECDSP_PRINT_DBG
#endif

#define VDEC_DEBUG_POS_ON 0
#if VDEC_DEBUG_POS_ON
#define PRINT_POS VDECDSP_PRINT_TRACE
#else
#define PRINT_POS VDECDSP_PRINT_DBG
#endif

#define PRINT_TRACE       VDECDSP_PRINT_TRACE
#define PRINT_ERROR       VDECDSP_PRINT_ERROR
#define PRINT_DEBUG_FLOW  VDECDSP_PRINT_TRACE

typedef struct _AtcVidDecInst ATCVIDDECINST;

typedef struct _AtcVidDecInputFormatInfo ATCVIDDECINPUTFMTINFO;

struct _AtcVidDecInputFormatInfo
{
  char  *role;
  OMX_VIDEO_CODINGTYPE eFormat;
  __s32 width;
  __s32 height;
  __s32 fps_n;
  __s32 fps_d;
  bool  interlaced;
};

typedef  struct _AtcVidDecOutputCfgInfo
{
  __u32 max_buf_cnt;
  __u32 min_buf_cnt;
  __u32 cur_buf_cnt;
  bool  had_set_bufcnt;
} ATCVIDDECOUTPUTCFGINFO;

typedef void (*ATCVIDDECINSTCB) (ATCVIDDECINST * decoder);

struct _AtcVidDecInst
{
  AtcOmxCore *gomx;
  AtcOmxPort *in_port;
  AtcOmxPort *out_port;

  bool use_timestamps;   /** @todo remove; timestamps should always be used */
  bool ready;
  GMutex   ready_lock;

  ATCVIDDECINSTCB omx_setup;
  ATC_VDEC_ERRCODE last_error_ret;
  
  ATCVIDDECINPUTFMTINFO input_format;
  ATCVIDDECOUTPUTCFGINFO output_cfg;

  bool had_set_infmt;
  bool set_omxbuffer;

  __s64   last_TimeStamp; /* unit: us */

  void *  output_tmp_buf;
  __s32    output_tmp_buf_sz;

    /** @todo these are hacks, OpenMAX IL spec should be revised. */
  bool share_input_buffer;
  bool share_output_buffer;
};

static inline void
log_buffer (ATCVIDDECINST * self, OMX_BUFFERHEADERTYPE * omx_buffer)
{
  PRINT_TRACE("omx_buffer: "
      "size=%lu, "
      "len=%lu, "
      "flags=%lu, "
      "offset=%lu, "
      "timestamp=%lld",
      omx_buffer->nAllocLen, omx_buffer->nFilledLen, omx_buffer->nFlags,
      omx_buffer->nOffset, omx_buffer->nTimeStamp);
}

static void
setup_ports (ATCVIDDECINST * self)
{
  PRINT_TRACE("setup_ports enter");
  /* Input port configuration. */
  atc_omx_port_setup (self->in_port);

  /* Output port configuration. */
  atc_omx_port_setup (self->out_port);

  self->in_port->omx_allocate = TRUE;
  self->out_port->omx_allocate = TRUE;

  PRINT_TRACE("setup_ports: in: %s, out: %s",
      self->in_port->omx_allocate ? "TRUE" : "FALSE",
      self->out_port->omx_allocate ? "TRUE" : "FALSE");
  PRINT_TRACE("setup_ports end");
}

static bool
omx_setup (ATCVIDDECINST * self)
{
  OMX_ERRORTYPE omx_err   = OMX_ErrorNone;
  OMX_INDEXTYPE index = OMX_IndexComponentStartUnused;
  OMX_BOOL atcVidDecoder = OMX_FALSE;
  AtcOmxCore *gomx = NULL;
  OMX_PARAM_PORTDEFINITIONTYPE port_def;

  gomx = (AtcOmxCore *) self->gomx;
  
  omx_err = atc_omx_port_get_port_definition(self->in_port, &port_def);
  if (omx_err != OMX_ErrorNone) {
    PRINT_ERROR("%s line %d fail in get omx component input port definition, err: 0x%08x\r\n",
      __FUNCTION__, __LINE__, omx_err);
    return FALSE;
  }
  
  PRINT_TRACE("%s -- eCompressionFormat = %d\r\n",
    __FUNCTION__, self->input_format.eFormat);
  port_def.format.video.eCompressionFormat = self->input_format.eFormat;

  omx_err = atc_omx_port_update_port_definition(self->in_port, &port_def);
  if (omx_err != OMX_ErrorNone) {
    PRINT_ERROR("%s line %d fail in update omx component input port definition, err: 0x%08x\r\n",
      __FUNCTION__, __LINE__, omx_err);
    return FALSE;
  }

  omx_err = atc_omx_port_get_port_definition(self->out_port, &port_def);
  if (omx_err != OMX_ErrorNone) {
    PRINT_ERROR("%s line %d fail in get omx component input port definition, err: 0x%08x\r\n",
      __FUNCTION__, __LINE__, omx_err);
    return FALSE;
  }
  
  port_def.nBufferSize = sizeof(struct VOUT_PARAM);

  omx_err = atc_omx_port_update_port_definition(self->out_port, &port_def);
  if (omx_err != OMX_ErrorNone) {
    PRINT_ERROR("%s line %d fail in update omx component input port definition, err: 0x%08x\r\n",
      __FUNCTION__, __LINE__, omx_err);
    return FALSE;
  }

  if (NULL != self->output_tmp_buf) {
    if (port_def.nBufferSize > self->output_tmp_buf_sz) {
      g_free(self->output_tmp_buf);
      self->output_tmp_buf = (void *)g_malloc0(port_def.nBufferSize);
      if (NULL == self->output_tmp_buf) {
        PRINT_TRACE ("[atcomxvdecinst][%s] line %d fail for no memory\r\n",
          __FUNCTION__, __LINE__);
        return FALSE;
      }
      self->output_tmp_buf_sz = port_def.nBufferSize;
    }
  } else {
    self->output_tmp_buf = (void *)g_malloc0(port_def.nBufferSize);
    if (NULL == self->output_tmp_buf) {
      PRINT_TRACE ("[atcomxvdecinst][%s] line %d fail for no memory\r\n",
        __FUNCTION__, __LINE__);
      return FALSE;
    }
    self->output_tmp_buf_sz = port_def.nBufferSize;
  }

  PRINT_TRACE("%s succes\r\n", __FUNCTION__);

  return TRUE;
}

static bool
set_component_role(
  ATCVIDDECINST *atcomxvdec, AtcOmxCore *gomx, OMX_VIDEO_CODINGTYPE eVType) 
{
  OMX_ERRORTYPE err = OMX_ErrorNone;
  const char *role = NULL;
  __u32 role_len = 0;
  struct MimeToRole {
      const char *Role;
      OMX_VIDEO_CODINGTYPE compression_format;
  };
  const struct MimeToRole kMimeToRole[] = {
      { "video_decoder.vp8",   OMX_VIDEO_CodingVP8},
      { "video_decoder.avc" ,   OMX_VIDEO_CodingAVC},
      { "video_decoder.mpeg4",   OMX_VIDEO_CodingMPEG4},
      { "video_decoder.h263",   OMX_VIDEO_CodingH263},
      { "video_decoder.mpeg2" ,   OMX_VIDEO_CodingMPEG2},
      { "video_decoder.jpeg" ,   OMX_VIDEO_CodingMJPEG},
      { "video_decoder.rv"   ,   OMX_VIDEO_CodingRV},
      { "video_decoder.mpeg1" ,   OMX_VIDEO_CodingMPEG1},
      { "video_decoder.vc1",   OMX_VIDEO_CodingWMV},
      { "video_decoder.wmv1",   OMX_VIDEO_CodingWMV},
      { "video_decoder.wmv2",   OMX_VIDEO_CodingWMV},
      { "video_decoder.mjpeg",   OMX_VIDEO_CodingMJPEG},
      { "video_decoder.vp6",   OMX_VIDEO_CodingVP6   },
      { "video_decoder.vp8",   OMX_VIDEO_CodingVP8  },
      { "video_decoder.hevc",   OMX_VIDEO_CodingHEVC},
  };
  
  static const size_t kNumMimeToRole =
      sizeof(kMimeToRole) / sizeof(kMimeToRole[0]);
  
  size_t i;
  for (i = 0; i < kNumMimeToRole; ++i) {
      if (eVType == kMimeToRole[i].compression_format) {
          break;
      }
  }
  
  if (i == kNumMimeToRole) {
      return FALSE;
  }
  
  role = kMimeToRole[i].Role;
  
  PRINT_DEBUG ("[atcomxvdecinst][%s] line %d --> core->omx_state: %d\r\n",
    __FUNCTION__,__LINE__,
    atcomxvdec->gomx->omx_state);

  atcomxvdec->input_format.eFormat = eVType;
  if (NULL != atcomxvdec->input_format.role) {
    g_free(atcomxvdec->input_format.role);
  }


  role_len = strlen(role) + 1;
  if (role_len >= OMX_MAX_STRINGNAME_SIZE) {
    PRINT_TRACE ("[atcomxvdecinst][%s] line %d fail for invalid role name: %s\r\n",
      __FUNCTION__, __LINE__, role);
    return FALSE;
  }

  atcomxvdec->input_format.role = g_malloc0(sizeof(char) * role_len);
  if (NULL == atcomxvdec->input_format.role) {
    PRINT_TRACE ("[atcomxvdecinst][%s] line %d fail for no memory\r\n",
      __FUNCTION__, __LINE__);
    return FALSE;
  }

  memset(atcomxvdec->input_format.role, 0, role_len);
  strcpy((char *)atcomxvdec->input_format.role, role);

  if (role != NULL) {
    OMX_PARAM_COMPONENTROLETYPE roleParams;

    ATC_OMX_INIT_PARAM (&roleParams);
    memset(roleParams.cRole, 0, sizeof(roleParams.cRole));
    strcpy((char *)roleParams.cRole, role);

    err = OMX_SetParameter (gomx->omx_handle, OMX_IndexParamATCSetFormat,
      &roleParams);
    if (err != OMX_ErrorNone) {
      PRINT_ERROR("Error setting ATCVid parameters:(0x%08x)",err);
      return FALSE;
    }
  }
  
  PRINT_DEBUG ("[atcomxvdecinst][%s] line %d --> core->omx_state: %d\r\n",
    __FUNCTION__, __LINE__,
    atcomxvdec->gomx->omx_state);

  return TRUE;
}

void *atc_vdec_open(void)
{
  ATCVIDDECINST *decoder = NULL;

  g_omx_init();

  decoder = g_malloc0(sizeof(ATCVIDDECINST));

  if (NULL == decoder) {
    PRINT_TRACE("[ATCOMXVDECINST] %s fail for no memory\r\n",
      __FUNCTION__);
    goto OPEN_FAILED;
  }

  memset(decoder, 0, sizeof(ATCVIDDECINST));

  PRINT_TRACE("[VER][%s] %02d.%02d.%03d\r\n",
    ATC_OMXVDEC_INST_MOD,
    ATC_OMXVDEC_INST_MAJ,
    ATC_OMXVDEC_INST_MIN,
    ATC_OMXVDEC_INST_REV);

  decoder->gomx = atcomx_core_new (decoder,
    "libatcomxcore.so",
    "OMX.video_decoder.atc");
    //"OMX.video_decoder.atc.wfd");
  if (NULL == decoder->gomx) {
    PRINT_TRACE("[ATCOMXVDECINST] %s fail in open ATC OMX VDEC component\r\n",
      __FUNCTION__);
    goto OPEN_FAILED;
  }
  decoder->in_port = atc_omx_core_new_port (decoder->gomx, 0);
  if (NULL == decoder->gomx) {
    PRINT_TRACE("[ATCOMXVDECINST] %s fail in create input port for ATC OMX VDEC component\r\n",
      __FUNCTION__);
    goto OPEN_FAILED;
  }
  decoder->out_port = atc_omx_core_new_port (decoder->gomx, 1);
  if (NULL == decoder->gomx) {
    PRINT_TRACE("[ATCOMXVDECINST] %s fail in create output port for ATC OMX VDEC component\r\n",
      __FUNCTION__);
    goto OPEN_FAILED;
  }

  g_mutex_init(&decoder->ready_lock);
  decoder->ready = FALSE;

  decoder->omx_setup = omx_setup;
    
  decoder->gomx->settings_changed_cb = NULL;
  
  decoder->set_omxbuffer = FALSE;
  decoder->had_set_infmt = FALSE;
  
  decoder->last_error_ret = RET_ATCVDECINST_OK;
  
  decoder->use_timestamps = TRUE;
  decoder->last_TimeStamp = (__s64)-1;
  
  decoder->input_format.role = NULL;
  decoder->input_format.eFormat = OMX_VIDEO_CodingUnused;
  decoder->input_format.fps_n = 0;
  decoder->input_format.fps_d = 1;
  decoder->input_format.interlaced = FALSE;
  decoder->input_format.width = 0;
  decoder->input_format.height = 0;
  
  decoder->output_tmp_buf_sz = 0;
  decoder->output_tmp_buf = NULL;

  PRINT_TRACE("[atcomxvdecinst][%s] line %d success --> core->omx_state: %d\r\n",
    __FUNCTION__,__LINE__,
    decoder->gomx->omx_state);

  return decoder;

OPEN_FAILED:
  
  if (NULL != decoder->in_port) {
    PRINT_TRACE ("[atcomxvdecinst][%s] line %d --> atc_omx_port_finish(in_port)\r\n", __FUNCTION__,__LINE__);
    atc_omx_port_finish (decoder->in_port);
  }

  if (NULL != decoder->out_port) {
    PRINT_TRACE ("[atcomxvdecinst][%s] line %d --> atc_omx_port_finish(out_port)\r\n", __FUNCTION__,__LINE__);
    atc_omx_port_finish (decoder->out_port);
  }

  if (NULL != decoder->gomx) {
    PRINT_TRACE("[ATCOMXVDECINST] %s fail in open ATC OMX VDEC component\r\n",
      __FUNCTION__);
    PRINT_TRACE ("[atcomxvdecinst][%s] line %d --> atc_omx_core_stop\r\n", __FUNCTION__,__LINE__);
    atc_omx_core_stop (decoder->gomx);
    PRINT_TRACE ("[atcomxvdecinst][%s] line %d --> atc_omx_core_unload\r\n", __FUNCTION__,__LINE__);
    atc_omx_core_unload (decoder->gomx);
  }

  if (NULL != decoder) {
    g_free(decoder);
  }

  g_omx_deinit();

  return NULL;
}

bool atc_vdec_start(void *inst)
{
  ATCVIDDECINST *self = (ATCVIDDECINST *)inst;
  AtcOmxCore *gomx = NULL;

  PRINT_DEBUG ("[atcomxvdecinst][%s] line %d entry\r\n",
    __FUNCTION__,__LINE__);

  if (NULL == self) {
    PRINT_ERROR("[atcomxvdecinst][%s] line %d fail for invalid args\r\n",
      __FUNCTION__, __LINE__);
    return FALSE;
  }

  gomx = (AtcOmxCore *) self->gomx;
  if (NULL == gomx) {
    PRINT_ERROR("[atcomxvdecinst][%s] line %d fail for OpenMax ATC VDEC Component\r\n",
      __FUNCTION__, __LINE__);
    return FALSE;
  }

  g_mutex_lock (&self->ready_lock);

  if (!self->had_set_infmt) {
    PRINT_ERROR("[atcomxvdecinst][%s] line %d fail for input format hasn't been set\r\n",
      __FUNCTION__, __LINE__);
    g_mutex_unlock (&self->ready_lock);
    return FALSE;
  }

  g_atomic_int_set (&self->last_error_ret, RET_ATCVDECINST_OK);
  
  g_mutex_unlock (&self->ready_lock);

  if (G_UNLIKELY (gomx->omx_state == OMX_StateLoaded)) {
    g_mutex_lock (&self->ready_lock);

    PRINT_TRACE("omx: prepare");

    /** @todo this should probably go after doing preparations. */
    if (self->omx_setup) {
      self->omx_setup (self);
    }

    PRINT_TRACE ("[atcomxvdecinst][%s] setup_ports\r\n",__FUNCTION__);
    setup_ports (self);

    PRINT_TRACE ("[atcomxvdecinst][%s] line %d g_omx_core_prepare\r\n",
      __FUNCTION__,__LINE__);
    atc_omx_core_prepare (self->gomx);
    
    PRINT_TRACE ("[atcomxvdecinst][%s] line %d setup_buflist, had_set_infmt=%d\r\n",
      __FUNCTION__,__LINE__, self->had_set_infmt);
    if (!self->had_set_infmt) {
      g_mutex_unlock (&self->ready_lock);
      return FALSE;
    }

    self->ready = TRUE;

    g_mutex_unlock (&self->ready_lock);

    if (gomx->omx_state != OMX_StateIdle) {
      PRINT_ERROR("[atcomxvdecinst][%s] line %d fail in omx core prepare\r\n",
        __FUNCTION__, __LINE__);
      return FALSE;
    }

    PRINT_DEBUG_ETB ("[atcomxvdecinst][%s] line %d  --> g_omx_core_start\r\n",
      __FUNCTION__,__LINE__);
    atc_omx_core_start (gomx);
  
    PRINT_DEBUG ("[atcomxvdecinst][%s] line %d  --> gomx->omx_state = %d\r\n",
      __FUNCTION__,__LINE__, gomx->omx_state);
    if (gomx->omx_state != OMX_StateExecuting) {
      PRINT_ERROR("[atcomxvdecinst][%s] line %d fail in atc_omx_core_start\r\n",
        __FUNCTION__, __LINE__);
      return FALSE;
    }
  }

  /* we do not start the task yet if the pad is not connected */
  if (self->ready) {
    /** @todo link callback function also needed */
    atc_omx_port_resume (self->in_port);
    atc_omx_port_resume (self->out_port);
  }
  PRINT_ERROR("[atcomxvdecinst][%s] line %d success\r\n",
    __FUNCTION__, __LINE__);

  return TRUE;
}

bool  atc_vdec_get_output_formats(void *inst,
  __u64 *psupport_fmts, __u32 *pformat)
{
  if ((NULL == inst) || (NULL == psupport_fmts) || (NULL == pformat)) {
    PRINT_TRACE ("[atcomxvdecinst][%s] line %d fail for invalid args\r\n",
      __FUNCTION__, __LINE__);
    return FALSE;
  }

  *psupport_fmts = (1 << ATC_PIX_FMT_NV12M_PRIVATE1);
  *pformat = ATC_PIX_FMT_NV12M_PRIVATE1;

  return TRUE;
}

bool  atc_vdec_set_input_format(void *inst,
  ATC_VDEC_INPUT_FMT_INFO_T *format)
{
  ATCVIDDECINST *self = (ATCVIDDECINST *)inst;
  AtcOmxCore *gomx;
  OMX_PARAM_PORTDEFINITIONTYPE port_def;
  OMX_PARAM_COMPONENTROLETYPE roleParams;
  OMX_INDEXTYPE index = OMX_IndexComponentStartUnused;
  OMX_ERRORTYPE err = OMX_ErrorNone;
  bool fgRet = FALSE;
  bool is_format_change = FALSE;
  bool needs_disable = FALSE;
  OMX_ERRORTYPE omx_err = OMX_ErrorNone;
  OMX_BOOL is_our_extractor = OMX_TRUE;

  if ((NULL == self) || (NULL == format)) {
    PRINT_TRACE ("[atcomxvdecinst][%s] line %d fail for invalid args\r\n",
      __FUNCTION__, __LINE__);
    return FALSE;
  }

  memset(&roleParams, 0, sizeof(OMX_PARAM_COMPONENTROLETYPE));
  
  PRINT_DEBUG ("[atcomxvdecinst][%s] entry\r\n", __FUNCTION__);

  gomx = (AtcOmxCore *) self->gomx;
  if (NULL == gomx) {
    PRINT_ERROR("[atcomxvdecinst][%s] line %d fail for OpenMax ATC VDEC Component\r\n",
      __FUNCTION__, __LINE__);
    return FALSE;
  }

  PRINT_DEBUG ("[atcomxvdecinst][%s] line %d --> core->omx_state: %d\r\n", __FUNCTION__,__LINE__,
    gomx->omx_state);

  PRINT_DEBUG ("[atcomxvdecinst][%s] line %d --> width:%d, height:%d\r\n", __FUNCTION__,__LINE__,
  	format->width, format->height);

  atc_omx_port_get_port_definition (self->in_port, &port_def);

  /* Check if the caps change is a real format change or if only irrelevant
   * parts of the caps have changed or nothing at all.
   */
  is_format_change |= port_def.format.video.nFrameWidth != format->width;
  is_format_change |= port_def.format.video.nFrameHeight != format->height;
  //Check whether Framerate is changed. Need to onsider whether fps_d is 0.
  is_format_change |= ((port_def.format.video.xFramerate == 0) &&
  (format->fps_n != 0) && (format->fps_d != 0));
  if (format->fps_d != 0)
    is_format_change |= 
    (port_def.format.video.xFramerate != ((format->fps_n ) / (format->fps_d)));
  else{
    is_format_change |= (port_def.format.video.xFramerate != 0);
    PRINT_DEBUG_FLOW ("[atcomxvdecinst][%s] line %d --> fps_d of framerate is 0\r\n",
      __FUNCTION__,__LINE__);
  }

  needs_disable = (gomx->omx_state != OMX_StateLoaded);

  PRINT_DEBUG_FLOW ("[atcomxvdecinst][%s] line %d --> needs_disable: %d, is_format_change: %d\r\n",
    __FUNCTION__, __LINE__,
    needs_disable, is_format_change);

  /* If the component is not in Loaded state and a real format change happens
   * we have to disable the port and re-allocate all buffers. If no real
   * format change happened we can just exit here.
   */
  if (needs_disable && !is_format_change) {
    PRINT_DEBUG_FLOW ("[atcomxvdecinst][%s] line %d --> Already running and same input format\r\n",
      __FUNCTION__, __LINE__);
    return TRUE;
  }
 
  if (needs_disable && is_format_change) {
    if (!atc_vdec_stop(self)) {
      PRINT_DEBUG_FLOW ("[atcomxvdecinst][%s] line %d fail in atc_vdec_reset\r\n",
        __FUNCTION__, __LINE__);
      return FALSE;
    }
    atc_omx_core_populate(gomx);
  }

  self->input_format.fps_d = format->fps_d;
  self->input_format.fps_n = format->fps_n;
  self->input_format.width = format->width;
  self->input_format.height = format->height;
  self->input_format.interlaced = format->interlaced;

  PRINT_TRACE("[atcomxvdecinst][%s] line %d --> framerate_num: %d, framerate_denom: %d\r\n",
    __FUNCTION__, __LINE__,
    self->input_format.fps_n,
    self->input_format.fps_d);

  PRINT_DEBUG ("[atcomxvdecinst][%s] line %d --> VideoCodingType = 0x%08x\r\n", 
    __FUNCTION__, __LINE__, format->eVType);
    
  if (!set_component_role(self, gomx, format->eVType)) {
    PRINT_ERROR("fail in gst_omx_atcwfdviddec_set_component_role"); 
    return FALSE;
  }
  
  err = atc_omx_cmp_get_ext_idx(gomx,
    (OMX_STRING)"OMX.atc.index.extractorType", &index);
  if (err != OMX_ErrorNone) {
    PRINT_ERROR("[atc_viddec][%s] fail in get index.extractorType index, error is 0x%x\r\n",
      __FUNCTION__, err);
    return FALSE;
  }

  is_our_extractor = FALSE;

  PRINT_DEBUG_FLOW ("[atc_viddec][%s] set atc extractor type\r\n",__FUNCTION__);
  err = atc_omx_cmp_set_config(gomx, index, &is_our_extractor);
  if (err != OMX_ErrorNone) {
    PRINT_ERROR ("[atc_viddec][%s] fail in set index.extractorType config, error is 0x%x\r\n",
      __FUNCTION__, err);
    return FALSE;
  }
  
  PRINT_DEBUG ("[atcomxvdecinst][%s] line %d --> core->omx_state: %d\r\n",__FUNCTION__,__LINE__,
    gomx->omx_state);

  omx_err = atc_omx_port_get_port_definition(self->in_port, &port_def);
  if (NULL == gomx) {
    PRINT_ERROR("[atcomxvdecinst][%s] line %d fail in atc_omx_port_get_port_definition, err: 0x%08x\r\n",
      __FUNCTION__, __LINE__, omx_err);
    return FALSE;
  }
  port_def.format.video.nFrameWidth = self->input_format.width;
  port_def.format.video.nFrameHeight = self->input_format.height;
  omx_err = atc_omx_port_update_port_definition(self->in_port, &port_def);
  if (NULL == gomx) {
    PRINT_ERROR("[atcomxvdecinst][%s] line %d fail in atc_omx_port_update_port_definition, err: 0x%08x\r\n",
      __FUNCTION__, __LINE__, omx_err);
    return FALSE;
  }

  self->had_set_infmt = TRUE;
  
  PRINT_DEBUG ("[atcomxvdecinst][%s] exit, return %s \r\n", __FUNCTION__,
    (fgRet ? "TRUE" : "FALSE"));

  return TRUE;
}

bool  atc_vdec_decode(void *inst,
  __u8 *pdata, __u32 datasz, __s64 timestampus)
{
  AtcOmxCore *gomx = NULL;
  AtcOmxPort *in_port = NULL;
  ATCVIDDECINST *self = (ATCVIDDECINST *)inst;
  bool ret = FALSE;

  if (NULL == self) {
    PRINT_ERROR ("[atcomxvdecinst][%s] line %d fail for invalid args\r\n",
      __FUNCTION__, __LINE__);
    return FALSE;
  }

  gomx = self->gomx;
  
  if (NULL == gomx ) {
    PRINT_ERROR ("[atcomxvdecinst][%s] line %d fail for no omx core\r\n",
      __FUNCTION__, __LINE__);
    return FALSE;
  }

  PRINT_DEBUG ("[atcomxvdecinst][%s] line %d omx_state is %d\r\n",
    __FUNCTION__, __LINE__, gomx->omx_state);

  in_port = self->in_port;
  
  PRINT_DEBUG_ETB("[atcomxvdecinst][%s] line %d enabled=%d\r\n",
    __FUNCTION__,__LINE__,in_port->enabled);

  if (G_LIKELY (in_port->enabled)) {
    guint data_offset = 0;

    if (G_UNLIKELY (gomx->omx_state == OMX_StateIdle)) {
      PRINT_TRACE("omx: play");
      
      PRINT_DEBUG_ETB ("[atcomxvdecinst][%s] line %d  --> g_omx_core_start\r\n",
        __FUNCTION__,__LINE__);
      atc_omx_core_start (gomx);

      PRINT_DEBUG ("[atcomxvdecinst][%s] line %d  --> gomx->omx_state = %d\r\n",
        __FUNCTION__,__LINE__, gomx->omx_state);
      if (gomx->omx_state != OMX_StateExecuting)
        goto out_flushing;
    }

    if (G_UNLIKELY (gomx->omx_state != OMX_StateExecuting)) {
      PRINT_ERROR ("[atcomxvdecinst][%s] line %d  --> Whoa! very wrong\r\n",
        __FUNCTION__,__LINE__);
      goto out_flushing;
    }
    
    PRINT_DEBUG ("[atcomxvdecinst][%s] buffer_offset is %d, datasz is %d\r\n",
      __FUNCTION__, data_offset, datasz);
    
    while (data_offset < datasz) {
      OMX_BUFFERHEADERTYPE *omx_buffer;

      if (self->last_error_ret != RET_ATCVDECINST_OK ||
          !(gomx->omx_state == OMX_StateExecuting ||
            gomx->omx_state == OMX_StatePause)) {

        PRINT_DEBUG_ETB("[atcomxvdecinst][%s] last_error_ret is %d, omx_state is %d\r\n",
            __FUNCTION__,self->last_error_ret, gomx->omx_state);
        goto out_flushing;
      }
    
      omx_buffer = atc_omx_port_request_buffer (in_port);

      if (NULL == omx_buffer) {
        PRINT_DEBUG_ETB("[atcomxvdecinst][%s] line %d omx_buffer is NULL\r\n",
            __FUNCTION__, __LINE__);
        goto out_flushing;
      }
        
      if (G_LIKELY (omx_buffer)) {
        omx_buffer->nFlags &= ~(OMX_BUFFERFLAG_EOS | OMX_BUFFERFLAG_REPEAT | OMX_BUFFERFLAG_SIZECHANGE);
      }

      if (omx_buffer->nAllocLen - omx_buffer->nOffset <= 0) {
        atc_omx_port_release_buffer (in_port, omx_buffer);
        continue;
      }
            
      if (omx_buffer->nAllocLen > omx_buffer->nOffset + datasz) {    
        omx_buffer->nFilledLen = datasz;
        memcpy (omx_buffer->pBuffer + omx_buffer->nOffset,
          pdata + data_offset, omx_buffer->nFilledLen);
        omx_buffer->nFlags &= ~(OMX_BUFFERFLAG_DISCONTINUITY | OMX_BUFFERFLAG_TIMEOUTAU);
      } else {
        omx_buffer->nFilledLen = omx_buffer->nAllocLen - omx_buffer->nOffset;
        memcpy (omx_buffer->pBuffer + omx_buffer->nOffset,
          pdata + data_offset, omx_buffer->nFilledLen);
        omx_buffer->nFlags &= ~(OMX_BUFFERFLAG_DISCONTINUITY | OMX_BUFFERFLAG_TIMEOUTAU);
      }
    
      if (timestampus != ATC_CLOCK_TIME_NONE) {
        omx_buffer->nTimeStamp = timestampus;
      } else {
        omx_buffer->nTimeStamp = 0;
      }
            
      data_offset += omx_buffer->nFilledLen;
      PRINT_DEBUG_ETB("[atcomxvdecinst][%s] atc_omx_port_release_buffer, datasz: %d\r\n",
          __FUNCTION__, datasz);

      atc_omx_port_release_buffer (in_port, omx_buffer);
    }
    ret = TRUE;
  } else {
    PRINT_TRACE("done");
  }
  PRINT_DEBUG_ETB("[atcomxvdecinst][%s] exit, ret: %s\r\n",
    __FUNCTION__, (ret ? "TRUE" : "FALSE"));

  return ret;

  /* special conditions */
out_flushing:
  {
    if (gomx->omx_error) {
      PRINT_TRACE("[atcomxvdecinst] %s fail in ATC OMX VDEC Component, omx_err: 0x%08x\r\n",
        __FUNCTION__, gomx->omx_error);
    } else if ((gomx->omx_state != OMX_StateExecuting) &&
        (gomx->omx_state != OMX_StatePause)) {
      PRINT_TRACE("[atcomxvdecinst] %s fail for ATC OMX VDEC Component is in wrong state(%d)\r\n",
        __FUNCTION__, gomx->omx_state);
    }

    return FALSE;
  }
}

ATC_VDEC_ERRCODE atc_vdec_get_output_data(void * inst,
  ATC_VDEC_OUTPUT_DATA_INFO_T *prOutInfo)
{
  ATCVIDDECINST *self = (ATCVIDDECINST *)inst;
  AtcOmxCore *gomx = NULL;
  AtcOmxPort *out_port = NULL;
  ATC_VDEC_ERRCODE ret = RET_ATCVDECINST_OK;
  bool had_get_data = FALSE;

  if (NULL == self) {
    PRINT_ERROR ("[atcomxvdecinst][%s] line %d fail for invalid args\r\n",
      __FUNCTION__, __LINE__);
    return FALSE;
  }

  gomx = self->gomx;

  PRINT_DEBUG ("[atcomxvdecinst][%s] begin\r\n", __FUNCTION__);

  /* do not bother if we have been setup to bail out */
  if ((ret = g_atomic_int_get (&self->last_error_ret)) != RET_ATCVDECINST_OK) {
    PRINT_OUTLOOP_DEBUG("[atcomxvdecinst][%s] line %d, ret is %d\r\n",
      __FUNCTION__, __LINE__, ret);
    goto LEAVEGETOUTPUT;
  }

  while (!had_get_data) {
    if (!self->ready) {
      PRINT_OUTLOOP_DEBUG ("[atcomxvdecinst][%s] not ready\r\n",__FUNCTION__);
      ret = RET_ATCVDECINST_WRONG_STATE;
      return FALSE;
    }
    
    if ((ret = g_atomic_int_get (&self->last_error_ret)) != RET_ATCVDECINST_OK) {
      PRINT_OUTLOOP_DEBUG("[atcomxvdecinst][%s] line %d, ret is %d\r\n",
        __FUNCTION__, __LINE__, ret);
      ret = RET_ATCVDECINST_WRONG_STATE;
      goto LEAVEGETOUTPUT;
    }

    if (G_UNLIKELY (gomx->omx_state != OMX_StateExecuting)) {
      PRINT_OUTLOOP_DEBUG ("[atcomxvdecinst][%s] not in OMX_StateExecuting\r\n", __FUNCTION__);
      ret = RET_ATCVDECINST_WRONG_STATE;
      goto LEAVEGETOUTPUT;
    }
  
    out_port = self->out_port;
  
#if 0
    PRINT_DEBUG("[atcomxvdecinst][%s] line %d -- enabled: %s\r\n",
      __FUNCTION__,__LINE__, ((out_port->enabled) ? "TRUE" : "FALSE"));
#endif
    if (out_port->enabled) {
      OMX_BUFFERHEADERTYPE *omx_buffer = NULL;
  #if 0
      PRINT_DEBUG ("[atcomxvdecinst][%s] line %d gst_omx_atcwfdviddec_had_set_infmt\r\n",
        __FUNCTION__,__LINE__);
      PRINT_DEBUG("[atcomxvdecinst][%s] begin request output buffer\r\n",  __FUNCTION__);
  #endif
      omx_buffer = atc_omx_port_request_buffer(out_port);
      if (G_UNLIKELY (!omx_buffer)) {
        PRINT_DEBUG("[atcomxvdecinst][%s] omx_buffer is NULL, don't start fillbuffer thread\r\n",
          __FUNCTION__);
        goto LEAVEGETOUTPUT;
      }
  
      log_buffer (self, omx_buffer);
  
      if (G_LIKELY (omx_buffer->nFilledLen > 0)) {
        PRINT_DEBUG("[atcomxvdecinst][%s] request hb %p, len=%lu, timeUS=%lld, nFlags: 0x%08x\r\n",
        __FUNCTION__,
        omx_buffer,
        omx_buffer->nFilledLen,
        omx_buffer->nTimeStamp,
        omx_buffer->nFlags);
      
        /** @todo we need to move all the caps handling to one single
               * place, in the output loop probably. */
        if (!(omx_buffer->nFlags & OMX_BUFFERFLAG_EOS)) {  
          if (self->use_timestamps) {
            prOutInfo->timestampus = omx_buffer->nTimeStamp;
          }
          
          PRINT_OUTLOOP_DEBUG("[atcomxvdecinst] get_output_data line %d output_tmp_buf: %p, Outbuf: %p, ofst: %d, omx's buf: %p\r\n",
            __LINE__, self->output_tmp_buf, prOutInfo->buffer,
            omx_buffer->nOffset, omx_buffer->pBuffer);
          memcpy(self->output_tmp_buf, prOutInfo->buffer,
            self->output_tmp_buf_sz);
          
          memcpy (prOutInfo->buffer,
              omx_buffer->pBuffer + omx_buffer->nOffset,
              omx_buffer->nFilledLen);
          
          memcpy(omx_buffer->pBuffer + omx_buffer->nOffset,
            self->output_tmp_buf,
            omx_buffer->nFilledLen);
          
          prOutInfo->datasz = omx_buffer->nFilledLen;
  
          self->last_TimeStamp = omx_buffer->nTimeStamp;
  
          if (NULL != omx_buffer->pOutputPortPrivate) {
            OMX_OUTPUTPORT_PRIVATE * priv = 
              (OMX_OUTPUTPORT_PRIVATE *)(omx_buffer->pOutputPortPrivate);
            prOutInfo->width = priv->rPicSize.u4Width;
            prOutInfo->height = priv->rPicSize.u4Height;
          }

          had_get_data = TRUE;
          ret = RET_ATCVDECINST_OK;
        }
        else {
          PRINT_ERROR("[atcomxvdecinst][%s] line %d error, nFlags: 0x%08x\r\n",
            __FUNCTION__, __LINE__, omx_buffer->nFlags);
        }
      }
  
      if (omx_buffer->nFlags & OMX_BUFFERFLAG_VIDFRAMENOTSUPPORT) {
        omx_buffer->nFlags &= ~OMX_BUFFERFLAG_VIDFRAMENOTSUPPORT;
        g_usleep(ATC_OUTLOOP_SEPERATE_TIME);
      } else if (omx_buffer->nFlags & OMX_BUFFERFLAG_NO_MEM) {
        PRINT_OUTLOOP_DEBUG ("[atcomxvdecinst][%s] line %d no memory\r\n",__FUNCTION__,__LINE__);
        omx_buffer->nFlags &= ~OMX_BUFFERFLAG_NO_MEM;
      } else {
        g_usleep(ATC_OUTLOOP_SEPERATE_TIME);
      }
      
  RELEAEBUF:
      
      omx_buffer->nFilledLen = 0;
      atc_omx_port_release_buffer (out_port, omx_buffer);
    }
    else {
      ret = RET_ATCVDECINST_WRONG_STATE;
    }
  }

LEAVEGETOUTPUT:

#if 0
  PRINT_DEBUG ("[atcomxvdecinst][%s] line %d exit, set last_error_ret = %d\r\n",
    __FUNCTION__, __LINE__, ret);
#endif

  self->last_error_ret = ret;

  if (gomx->omx_error != OMX_ErrorNone) {
    PRINT_TRACE ("[atcomxvdecinst][%s] line %d gomx->omx_error = %d\r\n",
      __FUNCTION__, __LINE__, gomx->omx_error);
    ret = RET_ATCVDECINST_COMPONENT_ERR;
  }

  return ret;
}

bool atc_vdec_stop(void *inst)
{
  ATCVIDDECINST *self = (ATCVIDDECINST *)inst;
  AtcOmxCore *gomx = NULL;

  PRINT_DEBUG ("[atcomxvdecinst][%s] line %d entry\r\n",
    __FUNCTION__,__LINE__);

  if (NULL == self) {
    PRINT_ERROR("[atcomxvdecinst][%s] line %d fail for invalid args\r\n",
      __FUNCTION__, __LINE__);
    return FALSE;
  }

  gomx = (AtcOmxCore *) self->gomx;
  if (NULL == gomx) {
    PRINT_ERROR("[atcomxvdecinst][%s] line %d fail for OpenMax ATC VDEC Component\r\n",
      __FUNCTION__, __LINE__);
    return FALSE;
  }

  /* persuade task to bail out */
  g_atomic_int_set (&self->last_error_ret, RET_ATCVDECINST_FLUSHING);

  g_mutex_lock (&self->ready_lock);

  if (self->ready) {
    /** @todo disable this until we properly reinitialize the buffers. */
    /* unlock loops */
    atc_omx_core_flush_start (gomx);
    atc_omx_core_flush_stop (gomx);
    
    /* unlock */
    PRINT_TRACE ("[atcomxvdecinst][%s] line %d --> atc_omx_port_pause(in_port)\r\n", __FUNCTION__,__LINE__);
    atc_omx_port_pause (self->in_port);
    PRINT_TRACE ("[atcomxvdecinst][%s] line %d --> atc_omx_port_pause(out_port)\r\n", __FUNCTION__,__LINE__);
    atc_omx_port_pause (self->out_port);
    
    PRINT_TRACE ("[atcomxvdecinst][%s] line %d --> g_omx_core_stop\r\n", __FUNCTION__,__LINE__);
    atc_omx_core_stop (self->gomx);
  }

  g_mutex_unlock (&self->ready_lock);

  return TRUE;
}

bool  atc_vdec_close(void *inst)
{
  ATCVIDDECINST *self = (ATCVIDDECINST *)inst;
  AtcOmxCore *gomx = NULL;

  if (NULL == self) {
    PRINT_TRACE ("[atcomxvdecinst][%s] line %d fail for invalid args\r\n",
      __FUNCTION__, __LINE__);
    return FALSE;
  }

  gomx = self->gomx;

  if (NULL == gomx) {
    PRINT_TRACE ("[atcomxvdecinst][%s] line %d fail for no omx component\r\n",
      __FUNCTION__, __LINE__);
    return FALSE;
  }

  g_mutex_lock (&self->ready_lock);

  if (self->ready) {
    /* unlock */
    PRINT_TRACE ("[atcomxvdecinst][%s] line %d --> g_omx_port_finish(in_port)\r\n", __FUNCTION__,__LINE__);
    atc_omx_port_finish (self->in_port);
    
    PRINT_TRACE ("[atcomxvdecinst][%s] line %d --> g_omx_port_finish(out_port)\r\n", __FUNCTION__,__LINE__);
    atc_omx_port_finish (self->out_port);
    
    PRINT_TRACE ("[atcomxvdecinst][%s] line %d --> g_omx_core_stop\r\n", __FUNCTION__,__LINE__);
    atc_omx_core_stop (gomx);
    
    PRINT_TRACE ("[atcomxvdecinst][%s] line %d --> g_omx_core_unload\r\n", __FUNCTION__,__LINE__);
    atc_omx_core_unload (gomx);
  
    PRINT_TRACE ("[atcomxvdecinst][%s] line %d --> g_omx_core_unload success\r\n", __FUNCTION__,__LINE__);
    self->ready = FALSE;        
    self->had_set_infmt = FALSE;
    self->set_omxbuffer = FALSE;
  }

  g_mutex_unlock (&self->ready_lock);
  PRINT_TRACE ("[atcomxvdecinst][%s] line %d --> core->omx_state: %d\r\n", __FUNCTION__,__LINE__,
    gomx->omx_state);
  if (gomx->omx_state != OMX_StateLoaded &&
      gomx->omx_state != OMX_StateInvalid) {
    PRINT_TRACE ("[atcomxvdecinst][%s] line %d GST_STATE_CHANGE_PAUSED_TO_READY fail for invalid omx_state: %d\r\n",
      __FUNCTION__,__LINE__, gomx->omx_state);
    return FALSE;
  }
  
  atc_omx_core_free (gomx);

  g_mutex_clear (&self->ready_lock);

  if (NULL != self->output_tmp_buf) {
    g_free(self->output_tmp_buf);
    self->output_tmp_buf = NULL;
    self->output_tmp_buf_sz = 0;
  }

  g_free(self);
  g_omx_deinit();

  return TRUE;
}

