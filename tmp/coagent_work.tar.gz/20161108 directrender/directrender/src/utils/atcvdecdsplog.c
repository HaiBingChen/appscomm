#include <errno.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <linux/types.h>

void atc_gstprintlognull(const char *log, ...)
{
  return;
}

