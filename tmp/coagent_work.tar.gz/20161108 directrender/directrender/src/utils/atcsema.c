
#include "atcsema.h"

ATCSEMA *
atc_sem_new (void)
{
  ATCSEMA *sem;

  sem = g_new (ATCSEMA, 1);
  g_cond_init(&(sem->condition));
  g_mutex_init(&(sem->mutex));
  sem->counter = 0;

  return sem;
}

void
atc_sem_free (ATCSEMA * sem)
{
  g_cond_clear (&(sem->condition));
  g_mutex_clear (&(sem->mutex));
  g_free (sem);
}

void
atc_sem_down (ATCSEMA * sem)
{
  g_mutex_lock (&(sem->mutex));

  while (sem->counter == 0) {
    g_cond_wait (&(sem->condition), &(sem->mutex));
  }

  sem->counter--;

  g_mutex_unlock (&(sem->mutex));
}

void
atc_sem_up (ATCSEMA * sem)
{
  g_mutex_lock (&(sem->mutex));

  sem->counter++;
  g_cond_signal (&(sem->condition));

  g_mutex_unlock (&(sem->mutex));
}


