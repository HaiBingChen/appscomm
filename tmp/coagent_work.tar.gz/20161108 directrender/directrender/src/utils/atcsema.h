#ifndef __ATC_VDECDSP_SEMA_H__
#define __ATC_VDECDSP_SEMA_H__

#include <glib.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _AtcSem ATCSEMA;

struct _AtcSem
{
  GCond condition;
  GMutex mutex;
  gint counter;
};


ATCSEMA *atc_sem_new (void);
void atc_sem_free (ATCSEMA * sem);
void atc_sem_down (ATCSEMA * sem);
void atc_sem_up (ATCSEMA * sem);

#ifdef __cplusplus
}
#endif

#endif /* __ATC_VDECDSP_SEMA_H__ */

